package com.evizcloud.soccerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoccerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoccerAppApplication.class, args);
	}

}
